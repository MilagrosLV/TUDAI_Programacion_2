package figuras;

public class Principal {

	public static void imprimir(Figura ff) {
		 System.out.println(ff);
	}
	
	
	public static void main(String[] args) {

        Figura ff = new FiguraFija(100,10);
       // ff.getRadio();
        imprimir(ff);
        Circulo c2 = new Circulo(10);
        
        Figura3D nueva = new Figura3D(c2, 100);
        
        System.out.println(nueva.getVolumen());
        
       
	}

}
