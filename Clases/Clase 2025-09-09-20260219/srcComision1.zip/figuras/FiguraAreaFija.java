package figuras;

public abstract class FiguraAreaFija extends Figura {

    private double area;
    
    public FiguraAreaFija(double aa) {
    	super("FiguraAreaFija");
    	area = aa;
    }
	public double getArea() {
		
		return area;
	}

	

}
