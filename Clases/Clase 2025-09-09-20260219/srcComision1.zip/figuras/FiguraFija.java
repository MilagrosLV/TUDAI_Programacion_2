package figuras;

public class FiguraFija extends FiguraAreaFija {

	private double perimetro;
	
	public FiguraFija(double area, double per) {
		super(area);
		perimetro = per;
		this.setNombre("FiguraFija");
	}
	
	public double getPerimetro() {
		
		return perimetro;
	}

}
