package figuras;

public abstract class Figura {

	private String nombre;
	
	public Figura(String ss) {
		nombre = ss;
	}
	
	public  abstract double getArea();
	public  abstract double getPerimetro();
	
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	//MetodoTemplate
	public String toString() {
		return nombre + "(" + this.getArea() + "," +
	             this.getPerimetro() + ")";
	}
	
}
