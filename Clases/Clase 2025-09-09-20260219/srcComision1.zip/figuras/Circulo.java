package figuras;

public class Circulo extends Figura {

	private double radio;
	
	public Circulo(double rr) {
		super("Circulo");
		radio = rr;
	}
	public double getArea() {
		return Math.PI*radio*radio;
	}
	
	public double getPerimetro() {
		return Math.PI*radio*2;
	}

	public double getRadio() {
		return radio;
	}

	public void setRadio(double radio) {
		this.radio = radio;
	}
	
	
}
