package empleados;

public class EmpleadoSueldoFijo extends Empleado {

	private double sueldo;
	
	public double getSueldo() {
		
		return sueldo;
	}

}
