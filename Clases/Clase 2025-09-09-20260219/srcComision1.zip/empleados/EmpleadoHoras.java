package empleados;

public class EmpleadoHoras extends Empleado{

	int horas;
	double valorH;
	
	public double getSueldo(){
		return valorH*horas;
	}
	
}
