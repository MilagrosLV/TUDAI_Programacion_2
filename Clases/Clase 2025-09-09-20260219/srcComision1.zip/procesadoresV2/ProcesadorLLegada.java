package procesadoresV2;

public class ProcesadorLLegada extends Procesador {

	public void agregarTarea(Tarea nueva) {
		misTareas.add(nueva);
	}

	public boolean esMenor(Tarea t1, Tarea t2) {
		
		return false;
	}

}
