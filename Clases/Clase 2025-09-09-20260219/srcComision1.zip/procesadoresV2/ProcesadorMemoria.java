package procesadoresV2;

public class ProcesadorMemoria extends Procesador {

	public boolean esMenor(Tarea ta, Tarea tb) {
		return ta.getUsoMemoria()<tb.getUsoMemoria();
	}

}
