package procesadoresV2;

public class Tarea {
	
	private int prioridad;
	private double usoCpu;
	private double usoMemoria;
	
	public Tarea(int prioridad, double usoCpu, double usoMemoria) {
		super();
		this.prioridad = prioridad;
		this.usoCpu = usoCpu;
		this.usoMemoria = usoMemoria;
	}
	public int getPrioridad() {
		return prioridad;
	}
	public void setPrioridad(int prioridad) {
		this.prioridad = prioridad;
	}
	public double getUsoCpu() {
		return usoCpu;
	}
	public void setUsoCpu(double usoCpu) {
		this.usoCpu = usoCpu;
	}
	public double getUsoMemoria() {
		return usoMemoria;
	}
	public void setUsoMemoria(double usoMemoria) {
		this.usoMemoria = usoMemoria;
	}
	
	public void ejecutar() {
		System.out.println("tarea : " + this.getPrioridad() + "-" + 
	                         this.getUsoCpu() + "," +
				             this.getUsoMemoria());
	}
	

}
