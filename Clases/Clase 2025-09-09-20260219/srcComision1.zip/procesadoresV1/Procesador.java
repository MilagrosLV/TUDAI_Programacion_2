package procesadoresV1;

import java.util.ArrayList;

public class Procesador {

	private ArrayList<Tarea> misTareas;
	
	public Procesador() {
		misTareas = new ArrayList<Tarea>();
	}
	
	public void agregarTarea(Tarea tt) {
		int pos = -1;
		int i = 0;
		while(i<misTareas.size() && pos == -1) {
			Tarea laOtra = misTareas.get(i);
			if (laOtra.getPrioridad() < tt.getPrioridad()) {
				pos = i;
			}
			i++;
		}
		
		if (pos ==-1) {
			misTareas.add(tt);
		} else {
			misTareas.add(pos, tt);
		}
	}
	
	public Tarea getPrimera() {
		if (misTareas.size()>0) {
			Tarea tt = misTareas.get(0);
			misTareas.remove(0);
			return tt;
		} else {
			return null;
		}
	}
	
	public void ejecutarTarea() {
		Tarea aEjecutar = this.getPrimera();
		if (aEjecutar!=null) {
			aEjecutar.ejecutar();
		}
	}
	
	public boolean hayTareas() {
		return misTareas.size()>0;
	}
	
	public ArrayList<Tarea> getTareas(){
		//ASI NO 
		//return misTareas; // ROMPE ENCAPSUMIENTO
		ArrayList<Tarea> copia = new ArrayList<Tarea>();
		copia.addAll(misTareas);
		return copia;
	}
}
