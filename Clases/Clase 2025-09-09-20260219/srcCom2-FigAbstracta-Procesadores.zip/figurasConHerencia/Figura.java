package figurasConHerencia;

public abstract class Figura {
    String nombre;

    public Figura(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public abstract double getArea();

    public abstract double getPerimetro();

    public String getDatosCompletos() {
        return "Nombre: " + this.getNombre() + " Area: " + this.getArea() + " Perimetro: " + this.getPerimetro();
    }

    
}
