package figurasConHerencia;

public abstract class FiguraAreaFija extends Figura {
    private double areaFija;

    public FiguraAreaFija(String nombre, double area) {
        super(nombre);
        this.areaFija = area;
    }

    public double getArea() {
        return this.areaFija;
    }
}
