package figurasConHerencia;

public class FiguraFija extends FiguraAreaFija {
    private double perimetroFijo;

    public FiguraFija(String nombre, double area, double perimetro) {
        super(nombre, area);
        this.perimetroFijo = perimetro;
    }

    public double getPerimetro() {
        return perimetroFijo;
    }

}
