package procesadores;

public class Principal {
    public static void main(String[] args) {
        Tarea t1 = new Tarea(2, 100, 30, 1);
        Tarea t2 = new Tarea(1, 1, 20, 2);
        Tarea t3 = new Tarea(3, 10, 10, 3);

        Procesador procXPrioridad = new ProcesadorPorPrioridad("Prior");
        Procesador procXMemoria = new ProcesadorPorMemoria("PorMem");
        Procesador procXCPU = new ProcesadorPorCPU("PorCPU");
        Procesador procXLlegada = new ProcesadorPorOrdenLlegada("Llegada");

        procXMemoria.agregar(t1);
        procXMemoria.agregar(t2);
        procXMemoria.agregar(t3);

        System.out.println(procXMemoria);

        procXLlegada.agregar(t3);
        procXLlegada.agregar(t1);
        procXLlegada.agregar(t2);
        

        System.out.println(procXLlegada);

        procXLlegada.ejecutar();

        System.out.println(procXLlegada);
    }

}
