package procesadores;

public class ProcesadorPorCPU extends ProcesadorPorOrden {
    public ProcesadorPorCPU(String nombre) {
        super(nombre);
    }

    public boolean esMenor(Tarea t1, Tarea t2) {
        return t1.getUsoCPU() < t2.getUsoCPU();
    }
}
