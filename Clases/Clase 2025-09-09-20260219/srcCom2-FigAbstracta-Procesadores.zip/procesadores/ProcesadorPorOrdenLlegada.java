package procesadores;

public class ProcesadorPorOrdenLlegada extends Procesador {

    public ProcesadorPorOrdenLlegada(String nombre) {
        super(nombre);
    }

    public void agregar(Tarea nueva) {
        this.tareas.add(nueva);
    }

}
