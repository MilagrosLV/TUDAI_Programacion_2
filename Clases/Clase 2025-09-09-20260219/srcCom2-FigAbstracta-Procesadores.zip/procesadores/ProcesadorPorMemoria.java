package procesadores;

public class ProcesadorPorMemoria extends ProcesadorPorOrden {
    public ProcesadorPorMemoria(String nombre) {
        super(nombre);
    }

    public boolean esMenor(Tarea t1, Tarea t2) {
        return t1.getUsoMem() < t2.getUsoMem();
    }
}
