package procesadores;

import java.util.ArrayList;

public abstract class Procesador {
protected ArrayList<Tarea> tareas;
    private String nombre;

    public Procesador(String nombre) {
        this.tareas = new ArrayList<>();
        this.nombre = nombre;
    }

    public String getNombre() {
        return this.nombre;
    }

    public boolean ejecutar() {
        if (this.tareas.isEmpty()) 
            return false;
        else {
            Tarea aEjecutar = this.tareas.remove(0); // Tomo y elimino la primera tarea de la lista
            aEjecutar.ejecutar();
            return true;
        }
    }

    public Tarea getTareaAEjecutar() {
        if (this.tareas.isEmpty())
            return null;
        else
            return this.tareas.get(0);
    }

    public String toString() {
        return this.getNombre() + ". Tareas: " + this.tareas;
    }

    public abstract void agregar(Tarea nueva);

    public void agregarSinRepetidos(Tarea nueva) {
        if (!this.tareas.contains(nueva))
            this.agregar(nueva);
    }

    
}
