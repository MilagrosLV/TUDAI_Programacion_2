package libreria;

import java.util.ArrayList;

public class Producto {

    private String nombre;
    private String autor;
    private CalculadorPrecio calculador;
    private int cantPaginas;
    private String resumen;
    private ArrayList<String> generos;

    public Producto(String nombre, String autor, CalculadorPrecio calculador, int cantPaginas, String resumen) {
        this.nombre = nombre;
        this.autor = autor;
        this.calculador = calculador;
        this.cantPaginas = cantPaginas;
        this.resumen = resumen;
        this.generos = new ArrayList<>();
    }

    public void addGenero(String genero) {
        if (!this.generos.contains(genero))
            this.generos.add(genero);
    }

    public boolean tieneGenero(String genero) {
        return this.generos.contains(genero);
    }

    public int getCantidadGeneros() {
        return this.generos.size();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public double getPrecio() {
        return this.calculador.getPrecio(this); // Se pasa a si mismo por parametro
    }

    public void setCalculador(CalculadorPrecio calculador) {
        this.calculador = calculador;
    }

    public int getCantPaginas() {
        return cantPaginas;
    }

    public void setCantPaginas(int cantPaginas) {
        this.cantPaginas = cantPaginas;
    }

    public String getResumen() {
        return resumen;
    }

    public void setResumen(String resumen) {
        this.resumen = resumen;
    }

    public boolean equals(Object otro) {
        try {   
            Producto otroP = (Producto)otro;
            return this.getNombre().equals(otroP.getNombre()) &&
                this.getAutor().equals(otroP.getAutor()); 
        }
        catch (Exception e) {
            return false;
        }
    }

    public String toString() {
        return this.getNombre() + " (" + this.getAutor() + ")";
    }

    

    

}
