package libreria;

public class CalculadorPrecioPorPaginas extends CalculadorPrecio {
    private double precioPorPagina;

    public CalculadorPrecioPorPaginas(double precioPorPagina) {
        this.precioPorPagina = precioPorPagina;
    }

    public double getPrecio(Producto producto) {
        return this.precioPorPagina * producto.getCantPaginas();
    }
}
