package libreria;

public class CalculadorPrecioSuma extends CalculadorPrecio {

    private CalculadorPrecio calculador1;
    private CalculadorPrecio calculador2;

    public CalculadorPrecioSuma(CalculadorPrecio calculador1, CalculadorPrecio calculador2) {
        this.calculador1 = calculador1;
        this.calculador2 = calculador2;
    }

    public double getPrecio(Producto producto) {
        return this.calculador1.getPrecio(producto) + this.calculador2.getPrecio(producto);
    }

}
