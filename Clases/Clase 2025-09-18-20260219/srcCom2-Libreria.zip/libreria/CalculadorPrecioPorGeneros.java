package libreria;

public class CalculadorPrecioPorGeneros extends CalculadorPrecio {
    private double precioPorGenero;

    public CalculadorPrecioPorGeneros(double precio) {
        this.precioPorGenero = precio;
    }

    public double getPrecio(Producto producto) {
        return this.precioPorGenero * producto.getCantidadGeneros();
    }
}
