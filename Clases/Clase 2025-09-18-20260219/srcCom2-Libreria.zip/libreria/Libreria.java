package libreria;

import java.util.ArrayList;

public class Libreria {
    private ArrayList<Cliente> clientes;
    private ArrayList<Producto> productos;

    public Libreria() {
        this.clientes = new ArrayList<>();
        this.productos = new ArrayList<>();
    }

    public void addCliente(Cliente cliente) {
        if (!this.clientes.contains(cliente))
            this.clientes.add(cliente); // Hace falta el equals redefinido
    }

    public void addProducto(Producto producto) {
        this.productos.add(producto);
    }

    public double calcularPrecio(Cliente cliente, Producto producto) {
        double precioProducto = producto.getPrecio();
        return precioProducto - (precioProducto * cliente.getDescuento());
    }

    public boolean yaCompro(Cliente cliente, Producto producto) {
        return cliente.yaCompro(producto);
    }

    public boolean leGustaACliente(Cliente cliente, Producto producto) {
        return cliente.leGusta(producto);
    }

    public ArrayList<Cliente> listarClientes(Producto producto) {
        ArrayList<Cliente> listado = new ArrayList<>();
        /*for (int i = 0; i < this.clientes.size(); i++) {
            Cliente cliente_i = this.clientes.get(i);
            if (cliente_i.leGusta(producto))
                listado.add(cliente_i);
        }
        */
        // Aun no lo usamos, pq no vimos el patron de diseño que hace que funcione
        for (Cliente cliente_i: this.clientes)
            if (cliente_i.leGusta(producto))
                listado.add(cliente_i);
        return listado;
    }
}
