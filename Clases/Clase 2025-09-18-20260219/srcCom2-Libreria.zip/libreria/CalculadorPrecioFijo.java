package libreria;

public class CalculadorPrecioFijo extends CalculadorPrecio {
    private double precioFijo;

    public CalculadorPrecioFijo(double precioFijo) {
        this.precioFijo = precioFijo;
    }

    public double getPrecio(Producto producto) {
        return this.precioFijo;
    }

}
