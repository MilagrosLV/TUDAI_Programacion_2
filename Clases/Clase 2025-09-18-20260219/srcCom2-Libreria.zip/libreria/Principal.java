package libreria;

public class Principal {

    public static void main(String[] args) {
        Cliente c1 = new ClienteExigente("Pepe", 1, "Tandil", 0.1);
        c1.addAutorFavorito("Cortazar");
        c1.addAutorFavorito("Saramago");
        c1.addGeneroFavorito("Distopia");
        c1.addGeneroFavorito("Policial");
        
        Cliente c2 = new Cliente("Tito", 2, "Tandil", 0.15);
        c2.addAutorFavorito("Bioy Casares");
        c2.addAutorFavorito("Garcia Marquez");
        c2.addGeneroFavorito("Realismo magico");
        c2.addGeneroFavorito("Suspenso");

        Cliente c3 = new ClienteLeGustaTodo("Pipo", 3, "Azul", 0.2);

        Producto a1 = new Producto("Rayuela", "Cortazar", 
                                    new CalculadorPrecioFijo(10), 300,
                                    "Horacio Oliveira y la maga...");
        a1.addGenero("Novela");

        Producto a2 = new Producto("Ensayo sobre la ceguera", "Saramago", 
                                    new CalculadorPrecioPorPaginas(0.1), 150,
                                    "Epidemia de ceguera");
        a2.addGenero("Suspenso");
        a2.addGenero("Distopia");

        Producto a3 = new Producto("La invención de Morel", "Bioy Casares",
                                    new CalculadorPrecioPorGeneros(5), 100,
                                    "En una isla desierta...");
        a3.addGenero("Ciencia ficcion");
        a3.addGenero("Fantasia");

        Producto a4 = new Producto("Cien años de soledad", "Garcia Marquez", 
                                    new CalculadorPrecioSuma(
                                        new CalculadorPrecioFijo(5), 
                                        new CalculadorPrecioSuma(
                                            new CalculadorPrecioPorPaginas(0.01),
                                            new CalculadorPrecioPorGeneros(2))),
                                    400, "Muchos años después, frente al pelotón de fusilamiento...");
        a4.addGenero("Realismo magico");
        
        c1.comprar(a2);

        Libreria alpha = new Libreria();
        alpha.addProducto(a1);
        alpha.addProducto(a2);
        alpha.addProducto(a3);
        alpha.addProducto(a4);

        alpha.addCliente(c1);
        alpha.addCliente(c2);
        alpha.addCliente(c3);

        System.out.println("El cliente c1 compro a2?: " + alpha.yaCompro(c1, a2));
        System.out.println("El cliente c1 compro a4?: " + alpha.yaCompro(c1, a4));

        System.out.println("A c1 le gusta a1? " + alpha.leGustaACliente(c1, a1));
        System.out.println("A c1 le gusta a2? " + alpha.leGustaACliente(c1, a2));
        System.out.println("A c1 le gusta a3? " + alpha.leGustaACliente(c1, a3));
        System.out.println("A c1 le gusta a4? " + alpha.leGustaACliente(c1, a4));

        System.out.println("A c2 le gusta a1? " + alpha.leGustaACliente(c2, a1));
        System.out.println("A c2 le gusta a2? " + alpha.leGustaACliente(c2, a2));
        System.out.println("A c2 le gusta a3? " + alpha.leGustaACliente(c2, a3));
        System.out.println("A c2 le gusta a4? " + alpha.leGustaACliente(c2, a4));

        System.out.println("Precio de a1 para c1: " + alpha.calcularPrecio(c1, a1));
        System.out.println("Precio de a2 para c1: " + alpha.calcularPrecio(c1, a2));
        System.out.println("Precio de a3 para c1: " + alpha.calcularPrecio(c1, a3));
        System.out.println("Precio de a4 para c1: " + alpha.calcularPrecio(c1, a4));

        System.out.println("Precio de a1 para c2: " + alpha.calcularPrecio(c2, a1));
        System.out.println("Precio de a2 para c2: " + alpha.calcularPrecio(c2, a2));
        System.out.println("Precio de a3 para c2: " + alpha.calcularPrecio(c2, a3));
        System.out.println("Precio de a4 para c2: " + alpha.calcularPrecio(c2, a4));

        System.out.println("Listado para a1: " + alpha.listarClientes(a1));
        System.out.println("Listado para a2: " + alpha.listarClientes(a2));
        System.out.println("Listado para a3: " + alpha.listarClientes(a3));
        System.out.println("Listado para a4: " + alpha.listarClientes(a4));
        


    }
}

