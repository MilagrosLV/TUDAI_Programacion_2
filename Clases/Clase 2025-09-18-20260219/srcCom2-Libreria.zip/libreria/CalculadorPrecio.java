package libreria;

public abstract class CalculadorPrecio {

    public abstract double getPrecio(Producto producto);
}
