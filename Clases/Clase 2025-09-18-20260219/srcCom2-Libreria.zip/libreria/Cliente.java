package libreria;

import java.util.ArrayList;

public class Cliente {

    private String nombre;
    private int dni;
    private String direccion;
    private ArrayList<String> autoresFavoritos;
    protected ArrayList<String> generosFavoritos;
    private ArrayList<Producto> compras;
    private double descuento;

    public Cliente(String nombre, int dni, String direccion, double descuento) {
        this.nombre = nombre;
        this.dni = dni;
        this.direccion = direccion;
        this.descuento = descuento;
        this.autoresFavoritos = new ArrayList<>();
        this.generosFavoritos = new ArrayList<>();
        this.compras = new ArrayList<>();
    }

    public void addAutorFavorito(String autor) {
        if (!this.autoresFavoritos.contains(autor))
            this.autoresFavoritos.add(autor);
    }

    public void addGeneroFavorito(String genero) {
        if (!this.generosFavoritos.contains(genero))
            this.generosFavoritos.add(genero);
    }

    public void comprar(Producto producto) {
        this.compras.add(producto);
    }

    public boolean existeAutorFavorito(String autor) {
        return this.autoresFavoritos.contains(autor);
    }

    public boolean existeGeneroFavorito(String genero) {
        return this.generosFavoritos.contains(genero);
    }

    public boolean yaCompro(Producto producto) {
        return this.compras.contains(producto); // Debo redefinir el equals en producto
    }

    public boolean leGusta(Producto producto) {
        //return this.autoresFavoritos.contains(producto.getAutor());
        return this.existeAutorFavorito(producto.getAutor());
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public int getDni() {
        return dni;
    }

    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    public double getDescuento() {
        return descuento;
    }
    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public boolean equals(Object otro) {
        try {
            Cliente otroC = (Cliente)otro;
            return this.getDni() == otroC.getDni();
        }
        catch (Exception e) {
            return false;
        }
    }

    public String toString() {
        return this.getNombre() + " (" + this.getDni() + ")";
    }

}
