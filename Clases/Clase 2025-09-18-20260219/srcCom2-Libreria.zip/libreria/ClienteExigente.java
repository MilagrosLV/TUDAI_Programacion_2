package libreria;

public class ClienteExigente extends Cliente {

    public ClienteExigente(String nombre, int dni, String direccion, double descuento) {
        super(nombre, dni, direccion, descuento);
    }

    public boolean leGusta(Producto producto) {
        // Chequear que el autor este entre los favoritos
        
        if (super.leGusta(producto)) {
            // y que tenga al menos un genero favorito
            for (int i = 0; i < this.generosFavoritos.size(); i++) {
                String genero_i = this.generosFavoritos.get(i);
                if (producto.tieneGenero(genero_i))
                    return true; // NO VALIDO PARA PROg1
            }
        }

        return false;
    }

}
