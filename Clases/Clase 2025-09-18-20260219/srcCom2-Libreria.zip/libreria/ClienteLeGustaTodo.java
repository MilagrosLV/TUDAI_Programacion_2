package libreria;

public class ClienteLeGustaTodo extends Cliente {

    public ClienteLeGustaTodo(String nombre, int dni, String direccion, double descuento) {
        super(nombre, dni, direccion, descuento);
    }

    public boolean leGusta(Producto producto) {
        return true;
    }
    

}
