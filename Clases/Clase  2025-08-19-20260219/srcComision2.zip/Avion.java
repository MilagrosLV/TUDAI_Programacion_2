public class Avion {

    // Atributos de la clase
    int capacidad;
    String modelo;
    String estado;

    // COnstructor sin parametros
    public Avion() {
        capacidad = 100;
        modelo = "Airbus 787";
        estado = "En tierra";
    }

    // Constructor con parametros
    public Avion(int cap, String mod, String est) {
        capacidad = cap;
        modelo = mod;
        estado = est;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int nuevaCapacidad) {
        capacidad = nuevaCapacidad;
    }
    
    public String getModelo() {
        return modelo;
    }

}
