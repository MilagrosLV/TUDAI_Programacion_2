public class Persona {
    String nombre;
    String apellido;
    int dni;
    String nacionalidad;
    //LocalDate fechaNaciemiento;

    public Persona(String nombre, String apellido, int dni, String nacionalidad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.nacionalidad = nacionalidad;
    }

    public String getNombre() {
        return this.nombre;
    }




}
