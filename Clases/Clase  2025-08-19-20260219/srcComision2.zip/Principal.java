public class Principal {
    public static void main(String[] args) {
        // Instancio una Avion
        Avion avion1 = new Avion();

        Avion avion2 = new Avion(50, "Boeing 444", "En reparacion");

        avion1.setCapacidad(120);
        avion2.setCapacidad(10);

        int capacidad1 = avion1.getCapacidad();

        System.out.println(capacidad1);

        int capacidad2 = avion2.getCapacidad();

        System.out.println(capacidad2);

        Persona pasajero1 = new Persona("Ariel", "Monteserin", 28, "Argentino");

        Vuelo vueloT_BsAs = new Vuelo("Tandil", "BsAs", avion1, "123");

        vueloT_BsAs.agregarPasajero(pasajero1);

        // vueloT_BsAs.pasajeros[0] = pasajero1; NOOOOOOOOOO, rompe encapsulamiento
    }
}
