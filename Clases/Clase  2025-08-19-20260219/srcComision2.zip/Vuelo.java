public class Vuelo {

    String origen;
    String destino;
    String nroVuelo;

    Avion avion;
    Persona[] pasajeros;
    int cantPasajeros;

    public Vuelo(String origen, String destino, Avion avion, String nroVuelo) {
        this.origen = origen;
        this.destino = destino;
        this.avion = avion;
        this.nroVuelo = nroVuelo;

        int maxcap = avion.getCapacidad();

        this.pasajeros = new Persona[maxcap];
        this.cantPasajeros = 0;
        
    }

    // Agregar un pasajero
    public boolean agregarPasajero(Persona pasajero) {
        if (this.cantPasajeros < pasajeros.length) {
            this.pasajeros[cantPasajeros] = pasajero;
            cantPasajeros++;
            return true;
        }
        else {
            return false;
        }

    }

}
