
public class Principal {

	public static void main(String[] args) {
	
		Avion xx=new Avion();
	
		System.out.println(xx.getCapacidad());
		System.out.println(xx.getModelo());
		System.out.println(xx.getColor());
	}

}
