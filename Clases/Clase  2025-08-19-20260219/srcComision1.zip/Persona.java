
public class Persona {

}
