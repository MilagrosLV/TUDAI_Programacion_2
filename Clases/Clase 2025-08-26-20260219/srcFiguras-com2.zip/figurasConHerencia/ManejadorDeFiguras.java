package figurasConHerencia;

public class ManejadorDeFiguras {
    
    public void imprimir(Figura f) {
        System.out.println(f.getDatosCompletos());
    }
}
