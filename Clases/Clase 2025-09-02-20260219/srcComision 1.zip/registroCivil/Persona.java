package registroCivil;

public class Persona {

	int dni;
	String nombre;
	private static Persona inicial;
	
	private static int contador =0;
	
	public Persona(String nn) {
	   
		dni = contador;
		contador++;
		nombre = nn;
		
		
		if (inicial == null) {
			inicial = this;
		}
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getDni() {
		return dni;
	}

	public static int getContador() {
	
		return contador ;
	}
	
	public static Persona getInicialDeTodos() {
		return inicial;
	}
	
	
}
