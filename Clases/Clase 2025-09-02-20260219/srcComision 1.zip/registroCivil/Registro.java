package registroCivil;

public class Registro {

	public static void main(String[] args) {
		
		System.out.println(Persona.getInicialDeTodos());
		
		Persona p1 = new Persona("Ana");
		Persona p2 = new Persona("Juan");
		System.out.println(p1.getDni());
		System.out.println(p2.getDni());
		Persona p3 = new Persona("Juan");
		System.out.println(p3.getDni());
		///
		///
		///
	    
		
		
		
		
		//p3.getContador();
		System.out.println(Persona.getContador());
	
		//Persona.setContador(45);
		
		System.out.println(Persona.getInicialDeTodos().getNombre());
	}
}
