package figuras;

public class Circulo extends Figura{

	public Circulo() {
		nombre = "Circulo";
		Figura f1 = new Figura();
		f1.nombre = "hola";
	}
	
	@Override
	public int getSuperficie() {
		return 4;
	}
}
