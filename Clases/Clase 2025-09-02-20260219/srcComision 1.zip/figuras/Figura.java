package figuras;

public class Figura {

	//Persona duenio;
	 String nombre;
	

	
	
	
	public int getSuperficie() {
		return 2;
	}
}
