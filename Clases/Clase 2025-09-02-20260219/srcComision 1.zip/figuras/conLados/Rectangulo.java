package figuras.conLados;


import java.util.*;

import figuras.Figura;

public class Rectangulo extends Figura{
	ArrayList lados;
	Date dd;
	
	public Rectangulo() {
		//nombre = "Circulo";
		Figura f1 = new Figura();
		//f1.nombre = "hola";
	}
}
