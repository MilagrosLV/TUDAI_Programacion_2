package clientes;

import java.util.ArrayList;

public class Empresa {
    String nombre;
    ArrayList<Cliente> clientes;

    public Empresa(String nombre) {
        this.nombre = nombre;
        this.clientes = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void addCliente(Cliente nuevo) {
        if (!clientes.contains(nuevo))
            this.clientes.add(nuevo);
    }

    public ArrayList<Cliente> getClientes() {
        return new ArrayList<>(this.clientes);
    }

    public String toString() {
        String aux = this.getNombre();
        for (int i = 0; i < this.clientes.size(); i++) {
            Cliente ci = this.clientes.get(i);
            aux = aux + " \n -" + ci; 
        }

        return aux;
    }

    public int getCantidadClientes() {
        return this.clientes.size();
    }

    public void eliminarCliente(Cliente aEliminar) {
        this.clientes.remove(aEliminar);
    }
}
