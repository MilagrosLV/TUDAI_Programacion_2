package clientes;

public class Cliente {

    private String nombre;
    private String dni;
    private int id;
    private String domicilio;

    private static int contador = 0;

    public Cliente(String nombre, String domicilio, String dni) {
        this.nombre = nombre;
        this.domicilio = domicilio;
        this.dni = dni;
        contador++;
        this.id = contador;
    }

    public static int getContador() {
        return contador;
    }

    //public static void resetContador() {
    //  /  contador = 0;
    //}

    public String getDNI() {
        return this.dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    @Override
    public String toString() {
        return this.getNombre() + "-" + this.getId() + " de " + Cliente.getContador();
    }

    public boolean equals(Object otro) {
        try {
            Cliente otroCliente = (Cliente)otro;
            return this.getDNI().equals(otroCliente.getDNI());
        }
        catch (Exception e) {
            return false;
        }
    }

}
