package clientes;

import java.util.ArrayList;

public class Principal {

    public static void main(String[] args) {
        Cliente ariel = new Cliente("Ariel", "Miramar","28");
        Cliente luis = new Cliente("Luis", "Olavarría","26");
        Cliente marce = new Cliente("Marce", "Azul","27");

        System.out.println(ariel);
        System.out.println(luis);

        //Cliente.resetContador();

        System.out.println(marce);

        Cliente sole = new Cliente("Sole", "Loberia","30");
        System.out.println(sole);

        Empresa uni = new Empresa("Uni");
        uni.addCliente(ariel);
        uni.addCliente(luis);
        uni.addCliente(marce);

        Cliente ariel2 = new Cliente("Ari", "Mir", "28");
        //uni.eliminarCliente(ariel2);

        System.out.println(uni);

        ArrayList<Cliente> clientesDeUni = uni.getClientes();
        clientesDeUni.add(ariel2);

        System.out.println(uni);

        System.out.println("Cantidad de clientes de Uni:");
        System.out.println(uni.getClientes().size()); // Mal delegada la responsabilidad
        System.out.println(uni.getCantidadClientes());
        
    }
}
