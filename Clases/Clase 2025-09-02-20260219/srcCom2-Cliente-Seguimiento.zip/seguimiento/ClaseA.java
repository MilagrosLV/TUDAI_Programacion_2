package seguimiento;

public class ClaseA {
    private double valor;

    public ClaseA(double valor) { 
        this.valor = valor; 
    }

    public double getValor() {
        return valor;
    }

    public String getDatoPrincipal() {
        return "Hola";
    }

    public String getDatoSecundario() {
        return "Chau";
    }

    public String toString() {
        return this.getDatoPrincipal() + "-" + this.getDatoSecundario();
    }

}
