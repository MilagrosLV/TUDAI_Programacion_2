package seguimiento;

public class ClaseE extends ClaseA {
    public static int MAX_NUM = 10;

    public ClaseE(double valor) {
        super(valor);
    }

    public String toString() {
        return super.toString() + "-" + this.getDatoTerciario();
    }

    public String getDatoTerciario() {
        return "Uhh";
    }
}
