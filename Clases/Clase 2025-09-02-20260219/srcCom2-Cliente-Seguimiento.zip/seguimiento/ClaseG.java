package seguimiento;

public class ClaseG extends ClaseE {

    public ClaseG(double valor) {
        super(valor);
    }
    
}
