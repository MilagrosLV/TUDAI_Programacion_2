package seguimiento;

public class ClaseF extends ClaseE {
    public ClaseF(double valor) {
        super(valor); 
    }
    
    public String getDatoPrincipal() {
        return "Buen dia";
    }
    
    public String getDatoTerciario() {
        return "Ohh";
    }
}
