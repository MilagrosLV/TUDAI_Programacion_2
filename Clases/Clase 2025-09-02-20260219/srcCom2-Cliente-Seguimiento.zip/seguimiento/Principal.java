package seguimiento;

public class Principal {

    public static void main(String[] args) {
        ClaseA ejemplo1 = new ClaseB(10);
        System.out.println(ejemplo1.getValor());

        ClaseA ejemplo2 = new ClaseE(10);
        System.out.println(ejemplo2);

        ClaseA ejemplo3 = (ClaseA) new ClaseF(20.5);
        System.out.println(ejemplo3);

        //ClaseF ejemplo4 = (ClaseA) new ClaseF(10.0);


        ClaseA ejemplo5 = new ClaseB(2);
        System.out.println(ejemplo5);

        ClaseA ejemplo6 = new ClaseD(2, 4);
        System.out.println(ejemplo6);

        ClaseA ejemplo7 = new ClaseA(8);
        System.out.println(ejemplo7);

        //ClaseA ejemplo8 = new ClaseF(4);
        //System.out.println(ejemplo8.getDatoTerciario());

        ClaseA ejemplo9 = new ClaseC();
        System.out.println(ejemplo9);




    }

}
