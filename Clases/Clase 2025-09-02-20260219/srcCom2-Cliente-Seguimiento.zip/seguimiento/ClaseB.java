package seguimiento;

public class ClaseB extends ClaseA {
    public ClaseB(double valor) { 
        super(valor * 2); 
    }
    
    public String getDatoSecundario() { 
        return "Nos vemos"; 
    }

    public String toString() {
        return this.getValor() + "-" + super.toString();
    }
}
