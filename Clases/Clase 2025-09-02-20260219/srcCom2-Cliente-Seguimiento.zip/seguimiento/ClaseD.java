package seguimiento;

public class ClaseD extends ClaseA {
    private double valor2;
    public ClaseD(double valor1, double valor2) {
        super(valor1);   
        this.valor2 = valor2;
   }

    public double getValor() {
        return super.getValor() * valor2;
    }
    
    public double calcular() {
        return valor2 * valor2 * 10;
    }
}
