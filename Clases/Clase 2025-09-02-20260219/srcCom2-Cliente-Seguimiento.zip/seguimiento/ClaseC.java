package seguimiento;

public class ClaseC extends ClaseB {
    public ClaseC() { 
        super(ClaseE.MAX_NUM);
    }
   
    public double getValor() { 
        return super.getValor() + 2;  
    }

    public String toString(String extra) {
        extra = "-Siiiii";
        return super.toString() + extra;
    }
}

