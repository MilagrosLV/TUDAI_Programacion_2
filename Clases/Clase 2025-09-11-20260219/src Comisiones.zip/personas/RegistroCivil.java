package personas;

import java.util.ArrayList;

public class RegistroCivil {

	private ArrayList<Persona>  personas;
	
	private FormaDeElegir  selector;
	//MONTON DE COSAS
	
	public Persona seleccionarPersona() {
		return selector.elegir(personas);
	}
	
	public void setSelector(FormaDeElegir nueva) {
		selector = nueva;
	}
	
	
}
