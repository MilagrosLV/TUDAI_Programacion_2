package personas;

import java.util.ArrayList;

public abstract class FormaDeElegir {

	
	public abstract Persona elegir(ArrayList<Persona> pp);
}
