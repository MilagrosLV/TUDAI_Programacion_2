package personas;

import java.util.ArrayList;

public class FEMenor  extends FormaDeElegir{

	public  Persona elegir(ArrayList<Persona> personas) {
		Persona menor = null;
		for(int i = 0; i<personas.size();i++) {
			Persona pp = personas.get(i);
			if (menor == null) {
				menor = pp;
			} else {
				if (menor.getDni()>pp.getDni()) {
					menor = pp;
				}
			}
			
		}
		return menor;
	};
	
}

