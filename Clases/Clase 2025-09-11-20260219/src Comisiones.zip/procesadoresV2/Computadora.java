package procesadoresV2;

import java.util.ArrayList;

public class Computadora {

	public static void main(String[] args) {

       Procesador pp = new Procesador();
       
       pp.agregarTarea( new Tarea(3,10,10));
       pp.agregarTarea( new Tarea(10,100,120));
       pp.agregarTarea( new Tarea(5,1,20));
       pp.agregarTarea( new Tarea(6,90,2));
       pp.agregarTarea( new Tarea(400,1000,200));
       
       Procesador paux = pp;
       
       pp.cambiarColaTareas(new ColaTareasCpu());
       
       while(paux.hayTareas()) {
    	   paux.ejecutarTarea();
       }
	}

}
