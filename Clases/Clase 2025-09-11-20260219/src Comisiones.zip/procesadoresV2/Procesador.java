package procesadoresV2;

import java.util.ArrayList;

public  class Procesador {
	protected  ColaTareas misTareas;
	
	public Procesador() {
		//misTareas = new ArrayList<Tarea>();
		//CREAR misTareas;
		misTareas = new ColaTareasPrioridad();
	}
	

	public void agregarTarea(Tarea tt) {
		misTareas.addTarea(tt);
		/*int pos = -1;
		int i = 0;
		while(i<misTareas.size() && pos == -1) {
			Tarea laOtra = misTareas.get(i);
			if (this.esMenor(laOtra,tt)) {
				pos = i;
			}
			i++;
		}
		
		if (pos ==-1) {
			misTareas.add(tt);
		} else {
			misTareas.add(pos, tt);
		}
		*/
	}
	
//	public abstract boolean esMenor(Tarea t1,Tarea t2);
	
	public Tarea getPrimera() {
		
		return misTareas.getPrimera();
	
	}
	
	public void ejecutarTarea() {
		Tarea aEjecutar = this.getPrimera();
		if (aEjecutar!=null) {
			aEjecutar.ejecutar();
		}
	}
	
	public boolean hayTareas() {
		 return misTareas.tieneTareas();
		//return misTareas.size()>0;
	}
	/*
	public ArrayList<Tarea> getTareas(){
		//ASI NO 
		//return misTareas; // ROMPE ENCAPSUMIENTO
		ArrayList<Tarea> copia = new ArrayList<Tarea>();
		copia.addAll(misTareas);
		return copia;
	}
	*/
	public void cambiarColaTareas(ColaTareas colaNueva) {
		while(misTareas.tieneTareas()) {
			colaNueva.addTarea(misTareas.getPrimera());
		}
		misTareas = colaNueva;
	}
}
