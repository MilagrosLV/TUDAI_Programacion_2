package procesadoresV2;

import java.util.ArrayList;

public abstract class ColaTareas {

	protected ArrayList<Tarea> tareas;
	
	public ColaTareas() {
		tareas = new ArrayList<Tarea>();
	}
	
	public void addTarea(Tarea tt) {
		int pos = -1;
		int i = 0;
		while(i<tareas.size() && pos == -1) {
			Tarea laOtra = tareas.get(i);
			if (this.esMenor(laOtra,tt)) {
				pos = i;
			}
			i++;
		}
		
		if (pos ==-1) {
			tareas.add(tt);
		} else {
			tareas.add(pos, tt);
		}
		
	}
	
	public abstract boolean esMenor(Tarea t1, Tarea t2);
	
	public Tarea getPrimera() {
		 if(tareas.size()>0) {
			 Tarea tt = tareas.get(0);
			 tareas.remove(0);
			 return tt;
		 } else {
			 return null;
		 }
	}
	public boolean tieneTareas() {
		return tareas.size()>0;
	}
	public int cantidadTareas() {
		return tareas.size();
	}
}
