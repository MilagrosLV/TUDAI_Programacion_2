package procesadoresV2;

public class ColaTareasMemoria extends ColaTareas {

	public boolean esMenor(Tarea t1, Tarea t2) {
		return t1.getUsoMemoria()<t2.getUsoMemoria();
	}

}
