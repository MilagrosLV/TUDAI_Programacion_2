package cooperativa;

import java.util.ArrayList;

public class Cooperativa {

    private String nombre;
    private ArrayList<Cereal> cereales;
    private ArrayList<Lote> lotes;

    private ArrayList<String> mineralesPrimarios;

    public Cooperativa(String nombre) {
        this.nombre = nombre;
        this.cereales = new ArrayList<>();
        this.lotes = new ArrayList<>();
        this.mineralesPrimarios = new ArrayList<>();
    }

    public void addCereal(Cereal nuevo) {
        if (!this.cereales.contains(nuevo))
            this.cereales.add(nuevo); // Me obliga a redefinir el equals
    }

    public void addLote(Lote nuevo) {
        this.lotes.add(nuevo);
    }

    public void addMineralPrimario(String nuevo) {
        if (!this.mineralesPrimarios.contains(nuevo))
            this.mineralesPrimarios.add(nuevo);
    }

    public ArrayList<Cereal> listarCerealParaLote(Lote lote) {
        ArrayList<Cereal> resultados = new ArrayList<>();
        for (int i = 0; i < this.cereales.size(); i++) {
            Cereal cereal_i = this.cereales.get(i);
            if (cereal_i.esApto(lote))
                resultados.add(cereal_i);
        }

        return resultados;
    }

    public ArrayList<Lote> listarLotesParaCereal(Cereal cereal) {
        ArrayList<Lote> resultados = new ArrayList<>();
        for (int i = 0; i < this.lotes.size(); i++) {
            Lote lote_i = this.lotes.get(i);
            //if (cereal.esApto(lote_i))
            if (lote_i.esApto(cereal))
                resultados.add(lote_i);
        }

        return resultados;
    }

    // Si tiene un mineral primario, es especial
    public boolean esEspecial(Lote lote) {
        for (int i = 0; i < this.mineralesPrimarios.size(); i++)
            if (lote.tieneMineral(this.mineralesPrimarios.get(i)))
                return true; // NO VALIDO PARA PROG1
        return false;
    }



}
