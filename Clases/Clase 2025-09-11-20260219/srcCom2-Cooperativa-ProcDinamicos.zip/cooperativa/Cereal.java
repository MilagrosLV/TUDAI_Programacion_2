package cooperativa;

import java.util.ArrayList;

public class Cereal {

    private String nombre;
    private ArrayList<String> mineralesNecesarios;

    public Cereal(String nombre) {
        this.nombre = nombre;
        this.mineralesNecesarios = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void addMineral(String mineralNuevo) {
        String nuevoEnMinuscula = mineralNuevo.toLowerCase();
        if (!this.mineralesNecesarios.contains(nuevoEnMinuscula))
            this.mineralesNecesarios.add(nuevoEnMinuscula);
    }

    public boolean esApto(Lote lote) {
        //int i = 0;
        /*boolean esApto = true;
        while (i < this.mineralesNecesarios.size() && esApto) {
            String mineral_i = this.mineralesNecesarios.get(i);
            esApto = lote.tieneMineral(mineral_i);
            i++;
        }

        return esApto;*/

        /*while (i < this.mineralesNecesarios.size() 
                        && lote.tieneMineral(this.mineralesNecesarios.get(i))) {
            i++;
        }
        return i == this.mineralesNecesarios.size(); */

        for (int i = 0; i < this.mineralesNecesarios.size(); i++)
            if (!lote.tieneMineral(this.mineralesNecesarios.get(i)))
                return false;

        return true;
    }

    public boolean equals(Object otro) {
        try {
            Cereal otroCereal = (Cereal)otro;
            return this.getNombre().equalsIgnoreCase(otroCereal.getNombre());
        }
        catch (Exception e) {
            return false;
        }
    }


    public String toString() {
        return this.getNombre();
    }


}
