package cooperativa;

public class Principal {
    public static void main(String[] args) {
        Cooperativa coop = new Cooperativa("Tandil");

        Lote l1 = new Lote("El gallo", 40);
        l1.addMineral("Fosforo");
        l1.addMineral("Hierro");
        Lote l2 = new Lote("Iraola", 60);
        l2.addMineral("Magnesio");

        Cereal maiz = new Cereal("Maiz");
        maiz.addMineral("Fosforo");
        Cereal trigo = new Cereal("Trigo");
        trigo.addMineral("Magnesio");
        trigo.addMineral("Hierro");
        Pastura alfalfa = new Pastura("Alfalfa", 50);
        alfalfa.addMineral("Magnesio");

        coop.addCereal(alfalfa);
        coop.addCereal(trigo);
        coop.addCereal(maiz);

        coop.addLote(l1);
        coop.addLote(l2);
        coop.addMineralPrimario("hierro");

        System.out.println(coop.listarCerealParaLote(l1));
        System.out.println(coop.listarCerealParaLote(l2));
        System.out.println(coop.listarLotesParaCereal(maiz));
        System.out.println(coop.listarLotesParaCereal(trigo));
        System.out.println(coop.listarLotesParaCereal(alfalfa));

        System.out.println(coop.esEspecial(l1));
        System.out.println(coop.esEspecial(l2));


    }

}
