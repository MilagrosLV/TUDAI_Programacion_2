package cooperativa;

public class Pastura extends Cereal {

    private int superficieMinima;

    public Pastura(String nombre, int superficie) {
        super(nombre);
        this.superficieMinima = superficie;
    }

    public int getSuperficieMinima() {
        return superficieMinima;
    }

    public void setSuperficieMinima(int superficieMinima) {
        this.superficieMinima = superficieMinima;
    }

    //@Override
    public boolean esApto(Lote lote) {
        if (lote.getTamanio() >= this.getSuperficieMinima())
            return super.esApto(lote);
        else
            return false;
    }



}
