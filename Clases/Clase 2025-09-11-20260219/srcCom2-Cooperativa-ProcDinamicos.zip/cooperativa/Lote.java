package cooperativa;

import java.util.ArrayList;

public class Lote {

    private String nombre;
    private ArrayList<String> minerales;
    private int tamanio;

    public Lote(String nombre, int tamanio) {
        this.nombre = nombre;
        this.tamanio = tamanio;
        this.minerales = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTamanio() {
        return tamanio;
    }

    public void setTamanio(int tamanio) {
        this.tamanio = tamanio;
    }

    public void addMineral(String mineralNuevo) {
        String nuevoEnMinuscula = mineralNuevo.toLowerCase();
        if (!this.minerales.contains(nuevoEnMinuscula))
            this.minerales.add(nuevoEnMinuscula);
    }

    public boolean tieneMineral(String mineral) {
        return this.minerales.contains(mineral);
    }

    public String toString() {
        return this.getNombre();
    }

    public boolean esApto(Cereal cereal) {
        return cereal.esApto(this);
    }

}
