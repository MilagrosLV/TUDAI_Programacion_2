package procesadoresDinamicos;

public class Procesador {
    
    private String nombre;
    private ColaDeTareas tareas;

    public Procesador(String nombre, ColaDeTareas coladetareas) {
        this.tareas = coladetareas;
        this.nombre = nombre;
    }

    public String getNombre() {
        return this.nombre;
    }

    public boolean ejecutar() {
        if (this.tareas.isEmpty()) 
            return false;
        else {
            Tarea aEjecutar = this.tareas.get(); // Tomo y elimino la primera tarea de la lista
            aEjecutar.ejecutar();
            return true;
        }
    }

    /*public Tarea getTareaAEjecutar() {
        if (this.tareas.isEmpty())
            return null;
        else
            return this.tareas.get();
    }*/

    public String toString() {
        return this.getNombre() + ". Tareas: " + this.tareas;
    }

    public void setColaDeTareas(ColaDeTareas nueva) {
        // this.tareas = nueva; se pierden las tareas que tenia
        // Recorrer las tareas actuales
        // Mientras tareas no este vacia
        // Mientras haya elementos en la cola actual
        while (!this.tareas.isEmpty()) {
            // Saco de la cola actual y pongo en la nueva
            // Las va agregar segun el nuevo orden
            nueva.agregar(this.tareas.get());
        }
        this.tareas = nueva;
    }

    public void agregar(Tarea nueva) {
        this.tareas.agregar(nueva);
    }

    
}
