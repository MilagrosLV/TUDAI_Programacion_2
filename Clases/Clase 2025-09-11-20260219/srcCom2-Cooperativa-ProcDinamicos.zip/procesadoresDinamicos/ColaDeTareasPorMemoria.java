package procesadoresDinamicos;

public class ColaDeTareasPorMemoria extends ColaDeTareasPorOrden {

    public boolean esMenor(Tarea t1, Tarea t2) {
        return t1.getUsoMem() < t2.getUsoMem();
    }
}
