package procesadoresDinamicos;

public abstract class ColaDeTareasPorOrden extends ColaDeTareas {
    
    /*public ColaDeTareasPorOrden() {
        super();
    }*/

    public void agregar(Tarea nueva) {
        // Agregue en forma ordenada: por prioridad
        int i = 0;
        while (i < this.tareas.size() && esMenor(this.tareas.get(i), nueva))
            i++;

        // en i voy a tener la posicion en la cual agregar
        this.tareas.add(i, nueva);
    }

    public abstract boolean esMenor(Tarea t1, Tarea t2);

    public String toString() {
        return "Ordenada: " + super.toString();
    }


}
