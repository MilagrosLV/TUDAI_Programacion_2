package procesadoresDinamicos;

public class Principal {
    public static void main(String[] args) {
        Tarea t1 = new Tarea(2, 100, 30, 1);
        Tarea t2 = new Tarea(1, 1, 20, 2);
        Tarea t3 = new Tarea(3, 10, 10, 3);

        Procesador procXPrioridad = new Procesador("Prior", new ColaDeTareasPorPrioridad());
        Procesador procXMemoria = new Procesador("Mem", new ColaDeTareasPorMemoria());
        Procesador procXCPU = new Procesador("PorCPU", new ColaDeTareasPorCPU());
        Procesador procXLlegada = new Procesador("Llegada", new ColaDeTareasPorOrdenLlegada());

        procXMemoria.agregar(t1);
        procXMemoria.agregar(t2);
        procXMemoria.agregar(t3);

        System.out.println(procXMemoria);

        procXMemoria.setColaDeTareas(new ColaDeTareasPorPrioridad());

        System.out.println(procXMemoria);

        procXMemoria.setColaDeTareas(new ColaDeTareasPorCPU());

        procXMemoria.agregar(new Tarea(10, 1, 1, 15));

        System.out.println(procXMemoria);

        procXLlegada.agregar(t3);
        procXLlegada.agregar(t1);
        procXLlegada.agregar(t2);
        

        System.out.println(procXLlegada);

        procXLlegada.ejecutar();

        System.out.println(procXLlegada);
    }

}
