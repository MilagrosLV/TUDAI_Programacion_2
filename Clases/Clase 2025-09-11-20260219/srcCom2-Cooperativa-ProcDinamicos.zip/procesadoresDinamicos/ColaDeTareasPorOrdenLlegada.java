package procesadoresDinamicos;

public class ColaDeTareasPorOrdenLlegada extends ColaDeTareas {

    public void agregar(Tarea nueva) {
        this.tareas.add(nueva);
    }

}
