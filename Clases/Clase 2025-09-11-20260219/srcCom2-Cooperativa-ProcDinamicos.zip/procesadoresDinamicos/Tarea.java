package procesadoresDinamicos;

public class Tarea {
    private int prioridad;
    private int usoMem;
    private int usoCPU;
    private int id;

    public Tarea(int prioridad, int usoMem, int usoCPU, int id) {
        this.prioridad = prioridad;
        this.usoMem = usoMem;
        this.usoCPU = usoCPU;
        this.id = id;
    }

    public void ejecutar() {
        System.out.println("Tarea " + this.getId() + " ejecutada..");
    }

    public int getPrioridad() {
        return prioridad;
    }
    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }
    public int getUsoMem() {
        return usoMem;
    }
    public void setUsoMem(int usoMem) {
        this.usoMem = usoMem;
    }
    public int getUsoCPU() {
        return usoCPU;
    }
    public void setUsoCPU(int usoCPU) {
        this.usoCPU = usoCPU;
    }
    public int getId() {
        return id;
    }

    public boolean equals(Object otro) {
        try {
            Tarea otraTarea = (Tarea)otro;
            return this.getId() == otraTarea.getId();
        }
        catch (Exception e) {
            return false;
        }
    }

    public String toString() {
        return "" + this.id;
    }

    
}
