package procesadoresDinamicos;

import java.util.ArrayList;

public abstract class ColaDeTareas {
    protected ArrayList<Tarea> tareas;

    public ColaDeTareas() {
        this.tareas = new ArrayList<>();
    }

    public abstract void agregar(Tarea nueva);

    public Tarea get() {
        if (this.tareas.isEmpty())
            return null;
        else
            return this.tareas.remove(0);
    }

    public boolean isEmpty() {
        return this.tareas.isEmpty();
    }

    public String toString() {
        return this.tareas.toString();
    }


}
