package academiaMagica;

import java.util.ArrayList;

public class Casa {

	private String nombreCasa;
	private ArrayList<String> cualidades;
	private int maxCap;
	protected ArrayList<Alumno> alumnos;
	
	public Casa(String nombreCasa, int maxCap) {
		super();
		this.nombreCasa = nombreCasa;
		this.maxCap = maxCap;
		cualidades = new ArrayList<String>();
		alumnos = new ArrayList<Alumno>();
	}

	public String getNombreCasa() {
		return nombreCasa;
	}

	public void setNombreCasa(String nombreCasa) {
		this.nombreCasa = nombreCasa;
	}

	public int getMaxCap() {
		return maxCap;
	}

	public void setMaxCap(int maxCap) {
		this.maxCap = maxCap;
	}
	
	public void addCualidad(String ss) {
		cualidades.add(ss);
		
	}
	
	public boolean tieneCalidad(String ss) {
		return cualidades.contains(ss);
	}
	
	public void removeCualidad(String ss) {
		cualidades.remove(ss);
	}
	
	public boolean estaLlena() {
		return  ! (maxCap<alumnos.size());
	}
	
	public boolean aceptaAlumno(Alumno aa) {
		
		if (! this.estaLlena() && aa.getPertenencia()==null) {
			for(int i = 0; i<cualidades.size();i++) {
				if (!aa.tieneCalidad(cualidades.get(i))) {
					return false;
				}
			}
			return true;
		} else {
			return false;
		}
		
	}
	
	public void agregarAlumno(Alumno aa) {
		if (this.aceptaAlumno(aa)) {
			alumnos.add(aa);
		    aa.setPertenencia(this);
		}	
	}
	
	
	
	
}
