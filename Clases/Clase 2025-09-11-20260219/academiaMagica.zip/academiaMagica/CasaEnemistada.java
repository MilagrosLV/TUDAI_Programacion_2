package academiaMagica;

public class CasaEnemistada extends Casa {

	Casa enemiga;

	public CasaEnemistada(String nombreCasa, int maxCap, Casa enemiga) {
		super(nombreCasa, maxCap);
		this.enemiga = enemiga;
	}

	public Casa getEnemiga() {
		return enemiga;
	}

	public void setEnemiga(Casa enemiga) {
		this.enemiga = enemiga;
	}
	
	public boolean aceptaAlumno(Alumno aa) {
		if (super.aceptaAlumno(aa) && ! enemiga.aceptaAlumno(aa)) {
			return true;
		} else {
			return false;
		}
			
	}
}
