package academiaMagica;

import java.util.ArrayList;

public class Alumno {

	private String nombre;
	private ArrayList<String> cualidades;
	private ArrayList<Alumno> familiares;
	private Casa pertenencia;
	
	public Alumno(String nombre) {
		super();
		this.nombre = nombre;
		pertenencia = null;
		cualidades = new ArrayList<String>();
		familiares = new ArrayList<Alumno>();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Casa getPertenencia() {
		return pertenencia;
	}

	public void setPertenencia(Casa pertenencia) {
		this.pertenencia = pertenencia;
	}
	
	public void addCualidad(String ss) {
		cualidades.add(ss);
		
	}
	
	public boolean tieneCalidad(String ss) {
		return cualidades.contains(ss);
	}
	
	public void removeCualidad(String ss) {
		cualidades.remove(ss);
	}
	
	public void addFamiliar(Alumno aa) {
		familiares.add(aa);
	}
	
	public boolean esFamiliar(Alumno aa) {
		return familiares.contains(aa);
	}
	
	
	public boolean equals(Object o1) {
		try {
		  Alumno aa = (Alumno) o1;
		  return nombre.equals(aa.getNombre());
		} catch(Exception e) {
			return false;
		}
	}
	
}
