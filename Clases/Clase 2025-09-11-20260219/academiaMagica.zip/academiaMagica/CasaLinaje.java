package academiaMagica;

public class CasaLinaje extends Casa {

	
	
	public CasaLinaje(String nombreCasa, int maxCap) {
		super(nombreCasa, maxCap);
		// TODO Auto-generated constructor stub
	}

	public boolean aceptaAlumno(Alumno aa) {
		
	   if (super.aceptaAlumno(aa)) {
		   for(int i = 0;i< alumnos.size();i++) {
			   if (aa.esFamiliar(alumnos.get(i))) {
				   return true;
			   }
		   }
		   return false;
	   } else {
		   return false;
	   }
	}
}
